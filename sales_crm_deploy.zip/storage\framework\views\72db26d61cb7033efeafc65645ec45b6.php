<?php
    $hasNotice = \HasinHayder\TyroDashboard\Services\AdminNotice::hasNotice();
?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($hasNotice): ?>
    <?php
        $message = \HasinHayder\TyroDashboard\Services\AdminNotice::getMessage();
        $bgColor = \HasinHayder\TyroDashboard\Services\AdminNotice::getBgColor();
        $textColor = \HasinHayder\TyroDashboard\Services\AdminNotice::getTextColor();
        $align = \HasinHayder\TyroDashboard\Services\AdminNotice::getAlign();
        $height = \HasinHayder\TyroDashboard\Services\AdminNotice::getHeight();
        
        $justifyContent = 'flex-start';
        if ($align === 'center') {
            $justifyContent = 'center';
        } elseif ($align === 'right') {
            $justifyContent = 'flex-end';
        }
    ?>
    <div id="tyro-admin-bar" style="
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: <?php echo e($height); ?>;
        background-color: <?php echo e($bgColor); ?>;
        color: <?php echo e($textColor); ?>;
        text-align: <?php echo e($align); ?>;
        z-index: 9999;
        display: flex;
        align-items: center;
        justify-content: <?php echo e($justifyContent); ?>;
        padding: 0 1rem;
        box-sizing: border-box;
    ">
        <?php echo $message; ?>

    </div>
    <style>
        :root {
            --admin-bar-height: <?php echo e($height); ?>;
        }
        .dashboard-layout {
            padding-top: var(--admin-bar-height);
        }
        .sidebar {
            top: var(--admin-bar-height) !important;
            height: calc(100vh - var(--admin-bar-height)) !important;
        }
    </style>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH C:\Users\Mahadi Hassan Arif\Desktop\Sales CRM\resources\views/vendor/tyro-dashboard/partials/admin-bar.blade.php ENDPATH**/ ?>