

<?php $__env->startSection('title', 'Salesperson Performance - ' . $user->name); ?>

<?php $__env->startSection('breadcrumb'); ?>
<a href="<?php echo e(route('tyro-dashboard.index')); ?>">Dashboard</a>
<span class="separator">/</span>
<span><?php echo e($user->name); ?> Performance</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div class="page-header-row">
        <div style="display: flex; align-items: center; gap: 1.5rem;">
            <div style="width: 80px; height: 80px; border-radius: 9999px; background: var(--primary); color: white; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 2rem; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);">
                <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

            </div>
            <div>
                <h1 class="page-title"><?php echo e($user->name); ?></h1>
                <p class="page-description"><?php echo e($user->email); ?> • <?php echo e($user->roles->first()->name ?? 'Sales Executive'); ?></p>
            </div>
        </div>
    </div>
</div>

<!-- Row 1: Individual KPIs -->
<div class="stats-grid" style="margin-bottom: 2rem;">
    <div class="stat-card">
        <div class="stat-icon stat-icon-primary">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
            </svg>
        </div>
        <div class="stat-content">
            <div class="stat-label">Conversion Rate</div>
            <div class="stat-value"><?php echo e($stats['conversion_rate']); ?>%</div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon stat-icon-success">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-10V6m0 12v-2m6-6a6 6 0 11-12 0 6 6 0 0112 0z" />
            </svg>
        </div>
        <div class="stat-content">
            <div class="stat-label">Monthly Revenue</div>
            <div class="stat-value">৳ <?php echo e(number_format($stats['monthly_revenue'], 2)); ?></div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon stat-icon-info">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
            </svg>
        </div>
        <div class="stat-content">
            <div class="stat-label">Total Visits</div>
            <div class="stat-value"><?php echo e(number_format($stats['total_visits'])); ?></div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon stat-icon-warning">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
        </div>
        <div class="stat-content">
            <div class="stat-label">Total Deals</div>
            <div class="stat-value"><?php echo e(number_format($stats['total_sales'])); ?></div>
        </div>
    </div>
</div>

<div class="grid-2" style="margin-bottom: 2rem;">
    <!-- Sales Trend -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Recent Sales Trend</h3>
        </div>
        <div class="card-body">
            <div style="height: 200px; display: flex; align-items: flex-end; gap: 1rem; padding-top: 1rem;">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $salesTrend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php ($maxAmount = collect($salesTrend)->max('amount') ?: 1); ?>
                    <?php ($height = ($trend['amount'] / $maxAmount) * 100); ?>
                    <div style="flex: 1; display: flex; flex-direction: column; align-items: center; gap: 0.5rem;">
                        <div style="width: 100%; background: var(--primary); border-radius: 4px 4px 0 0; height: <?php echo e(max(5, $height)); ?>%; opacity: <?php echo e(0.4 + ($height/200)); ?>;"></div>
                        <span style="font-size: 0.75rem; color: var(--muted-foreground);"><?php echo e($trend['month']); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Recent Assigned Leads -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Latest Assigned Leads</h3>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Company</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($recentLeads->count()): ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $recentLeads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div style="font-weight: 600;"><?php echo e($lead->company_name); ?></div>
                                    <div style="font-size: 0.75rem; color: var(--muted-foreground);"><?php echo e($lead->service->name ?? 'Service N/A'); ?></div>
                                </td>
                                <td>
                                    <span class="badge badge-secondary"><?php echo e(ucfirst($lead->status)); ?></span>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="2" style="text-align: center; padding: 2rem; color: var(--muted-foreground);">No leads assigned.</td>
                            </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tyro-dashboard::layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Mahadi Hassan Arif\Desktop\Sales CRM\resources\views/vendor/tyro-dashboard/reports/user-performance.blade.php ENDPATH**/ ?>