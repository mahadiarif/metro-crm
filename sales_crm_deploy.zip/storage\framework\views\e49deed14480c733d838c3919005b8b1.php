<?php $__env->startSection('title', 'Log Sales Call Activity'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<a href="<?php echo e(route('tyro-dashboard.index')); ?>">Dashboard</a>
<span class="breadcrumb-separator">/</span>
<a href="<?php echo e(route('tyro-dashboard.sales-calls.index')); ?>">Sales Calls</a>
<span class="breadcrumb-separator">/</span>
<span>Record Session</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="px-2">
    <div class="page-header d-flex justify-content-between align-items-center mb-6 text-left">
        <div>
            <h1 class="page-title text-slate-900 fw-bold mb-1">Tele-Sales Engagement Log</h1>
            <p class="text-xs text-slate-500 font-medium">Capture inbound/outbound call outcomes and service interest matrix.</p>
        </div>
        <a href="<?php echo e(route('tyro-dashboard.sales-calls.index')); ?>" class="btn btn-outline-slate btn-sm rounded-xl fw-bold text-xs">
            Back to History
        </a>
    </div>

    <!-- Expert Call Logging Form (Full-Page Mode) -->
    <div class="card border-0 shadow-sm rounded-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div class="card-body p-0">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('sales-call.outcome-modal', [
                'leadId' => request('lead_id'), 
                'isModalOpen' => true
            ]);

$__key = null;

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-2970416060-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key);

echo $__html;

unset($__html);
unset($__key);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>
</div>

<style>
    /* Flatten the modal behavior for full-page resource experience */
    .fixed.inset-0.z-50 {
        position: static !important;
        background: transparent !important;
        backdrop-filter: none !important;
    }
    .min-h-screen {
        min-height: auto !important;
        padding: 0 !important;
    }
    .max-w-4xl {
        max-width: 100% !important;
        box-shadow: none !important;
        border-radius: 0 !important;
    }
    .animate-in.fade-in.zoom-in {
        animation: none !important;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tyro-dashboard::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Mahadi Hassan Arif\Desktop\Sales CRM\resources\views/dashboard/sales-calls/create.blade.php ENDPATH**/ ?>