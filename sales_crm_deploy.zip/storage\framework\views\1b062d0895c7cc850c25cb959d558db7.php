

<?php $__env->startSection('title', 'Sales Report'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<a href="<?php echo e(route('tyro-dashboard.reports.sales')); ?>">Reports</a>
<span>/ Sales</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div class="page-header-row">
        <div>
            <h1 class="page-title">Sales Report</h1>
            <p class="page-description">Filter and analyze your sales pipeline data.</p>
        </div>
        <div class="page-header-actions" style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
            <a href="<?php echo e(request()->fullUrlWithQuery(['export' => 'csv'])); ?>" class="btn btn-secondary" style="display: flex; align-items: center; gap: 0.5rem;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 16px; height: 16px;"><path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" /></svg>
                CSV
            </a>
            <a href="<?php echo e(request()->fullUrlWithQuery(['export' => 'excel'])); ?>" class="btn btn-secondary" style="display: flex; align-items: center; gap: 0.5rem;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 16px; height: 16px;"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                Excel
            </a>
            <a href="<?php echo e(request()->fullUrlWithQuery(['export' => 'pdf'])); ?>" class="btn btn-secondary" style="display: flex; align-items: center; gap: 0.5rem;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 16px; height: 16px;"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" /></svg>
                PDF
            </a>
        </div>
    </div>
</div>


<div style="display: flex; gap: 1rem; margin-bottom: 1.5rem; flex-wrap: wrap;">
    <div class="card" style="flex: 1; min-width: 160px; padding: 1.25rem 1.5rem;">
        <div style="font-size: 0.8125rem; color: var(--muted-foreground); font-weight: 500;">Total Deals</div>
        <div style="font-size: 1.75rem; font-weight: 700; margin-top: 0.25rem;"><?php echo e(number_format($aggregates->total_deals)); ?></div>
    </div>
    <div class="card" style="flex: 1; min-width: 160px; padding: 1.25rem 1.5rem;">
        <div style="font-size: 0.8125rem; color: #10b981; font-weight: 500;">Total Revenue</div>
        <div style="font-size: 1.75rem; font-weight: 700; margin-top: 0.25rem; color: #10b981;">৳ <?php echo e(number_format($aggregates->total_revenue, 2)); ?></div>
    </div>
    <div class="card" style="flex: 1; min-width: 160px; padding: 1.25rem 1.5rem;">
        <div style="font-size: 0.8125rem; color: var(--muted-foreground); font-weight: 500;">Avg. Deal Value</div>
        <div style="font-size: 1.75rem; font-weight: 700; margin-top: 0.25rem;">
            ৳ <?php echo e($aggregates->total_deals > 0 ? number_format($aggregates->total_revenue / $aggregates->total_deals, 2) : '0.00'); ?>

        </div>
    </div>
</div>


<div class="card" style="margin-bottom: 1.5rem;">
    <div class="card-header">
        <div style="display: flex; align-items: center; gap: 0.5rem;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 16px; height: 16px; color: var(--muted-foreground);"><path stroke-linecap="round" stroke-linejoin="round" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" /></svg>
            <h3 class="card-title">Filters</h3>
        </div>
    </div>
    <div class="card-body">
        
        <div style="display: flex; gap: 0.5rem; margin-bottom: 1.25rem; flex-wrap: wrap;">
            <span style="font-size: 0.8125rem; font-weight: 500; color: var(--muted-foreground); align-self: center; margin-right: 0.25rem;">Quick:</span>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ['today' => 'Today', 'this_week' => 'This Week', 'this_month' => 'This Month']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(request()->fullUrlWithQuery(['quick' => $key, 'start_date' => '', 'end_date' => ''])); ?>"
                   class="btn <?php echo e(request('quick') === $key ? 'btn-primary' : 'btn-ghost'); ?>"
                   style="font-size: 0.8125rem; padding: 0.3rem 0.75rem; height: auto;">
                   <?php echo e($label); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request()->anyFilled(['quick','start_date','end_date','user_id','service_id','lead_status','zone'])): ?>
                <a href="<?php echo e(route('tyro-dashboard.reports.sales')); ?>" class="btn btn-ghost" style="font-size: 0.8125rem; padding: 0.3rem 0.75rem; height: auto; color: var(--muted-foreground);">✕ Clear all</a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        
        <form action="<?php echo e(route('tyro-dashboard.reports.sales')); ?>" method="GET">
            <div class="form-row" style="flex-wrap: wrap; gap: 1rem; align-items: flex-end;">
                <div class="form-group" style="margin-bottom: 0; flex: 1; min-width: 140px;">
                    <label class="form-label">Start Date</label>
                    <input type="date" name="start_date" class="form-input" value="<?php echo e(request('start_date')); ?>">
                </div>
                <div class="form-group" style="margin-bottom: 0; flex: 1; min-width: 140px;">
                    <label class="form-label">End Date</label>
                    <input type="date" name="end_date" class="form-input" value="<?php echo e(request('end_date')); ?>">
                </div>
                <div class="form-group" style="margin-bottom: 0; flex: 1; min-width: 140px;">
                    <label class="form-label">Executive</label>
                    <select name="user_id" class="form-select">
                        <option value="">All Executives</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php echo e(request('user_id') == $user->id ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </select>
                </div>
                <div class="form-group" style="margin-bottom: 0; flex: 1; min-width: 140px;">
                    <label class="form-label">Product</label>
                    <select name="service_id" class="form-select">
                        <option value="">All Products</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($service->id); ?>" <?php echo e(request('service_id') == $service->id ? 'selected' : ''); ?>><?php echo e($service->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </select>
                </div>
                <div class="form-group" style="margin-bottom: 0; flex: 1; min-width: 140px;">
                    <label class="form-label">Lead Status</label>
                    <select name="lead_status" class="form-select">
                        <option value="">All Statuses</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ['new', 'contacted', 'interested', 'closed', 'lost']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($st); ?>" <?php echo e(request('lead_status') == $st ? 'selected' : ''); ?>><?php echo e(ucfirst($st)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </select>
                </div>
                <div class="form-group" style="margin-bottom: 0; flex: 1; min-width: 140px;">
                    <label class="form-label">Zone / Territory</label>
                    <select name="zone" class="form-select">
                        <option value="">All Zones</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($zone); ?>" <?php echo e(request('zone') == $zone ? 'selected' : ''); ?>><?php echo e($zone); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </select>
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="visibility: hidden;">Go</label>
                    <button type="submit" class="btn btn-primary">Apply Filters</button>
                </div>
            </div>
    </div>
</div>


<div class="card" style="margin-bottom: 1rem;">
    <div class="card-body">
        <div class="filters-bar" style="display: flex; gap: 10px; align-items: center; justify-content: space-between;">
            <div class="search-box" style="display: flex; gap: 10px; align-items: center;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 14px; height: 14px; color: var(--muted-foreground);">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                <input type="text" name="search" class="form-input" placeholder="Search..." value="<?php echo e(request('search')); ?>">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request('search')): ?>
                    <a href="<?php echo e(request()->fullUrlWithQuery(['search' => ''])); ?>" class="btn btn-ghost" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;">Clear Search</a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </div>
</div>
</form>


<div class="card">
    <div class="card-body" style="padding: 0;">
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Date</th>
                        <th>Lead / Company</th>
                        <th>Executive</th>
                        <th>Product</th>
                        <th style="text-align: right;">Amount</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td style="color: var(--muted-foreground); font-size: 0.8125rem;"><?php echo e(($sales->currentPage() - 1) * $sales->perPage() + $i + 1); ?></td>
                            <td style="white-space: nowrap;"><?php echo e($sale->closed_at->format('d M Y')); ?></td>
                            <td>
                                <div style="font-weight: 600;"><?php echo e($sale->lead->company_name ?? 'N/A'); ?></div>
                                <div style="font-size: 0.75rem; color: var(--muted-foreground);"><?php echo e($sale->lead->client_name ?? ''); ?></div>
                            </td>
                            <td><?php echo e($sale->user->name ?? 'N/A'); ?></td>
                            <td><span class="badge badge-secondary"><?php echo e($sale->service->name ?? 'N/A'); ?></span></td>
                            <td style="text-align: right; font-weight: 700; color: #10b981; white-space: nowrap;">৳ <?php echo e(number_format($sale->amount, 2)); ?></td>
                            <td><span style="font-size: 0.8125rem; color: var(--muted-foreground);"><?php echo e(Str::limit($sale->remarks, 60)); ?></span></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 4rem; color: var(--muted-foreground);">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="width: 40px; height: 40px; margin: 0 auto 1rem; display: block; opacity: 0.4;"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25M9 16.5v.75m3-3v3M15 12v5.25m-4.5-15H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" /></svg>
                                No sales records found for the selected filters.
                            </td>
                        </tr>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sales->hasPages()): ?>
        <div style="padding: 1.25rem 1.5rem; border-top: 1px solid var(--border);">
            <?php echo e($sales->links('tyro-dashboard::partials.pagination')); ?>

        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.querySelector('input[name="search"]');
        if (searchInput) {
            let timeout = null;
            searchInput.addEventListener('input', function() {
                clearTimeout(timeout);
                timeout = setTimeout(() => {
                    this.closest('form').submit();
                }, 500); // 500ms debounce
            });

            // Maintain focus after refresh
            if (searchInput.value) {
                searchInput.focus();
                const val = searchInput.value;
                searchInput.value = '';
                searchInput.value = val;
            }
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tyro-dashboard::layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Mahadi Hassan Arif\Desktop\Sales CRM\resources\views/vendor/tyro-dashboard/reports/sales.blade.php ENDPATH**/ ?>