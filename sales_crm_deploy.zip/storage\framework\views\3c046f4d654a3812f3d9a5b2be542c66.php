<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="light">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="color-scheme" content="light dark">

    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> - <?php echo e($branding['app_name'] ?? config('tyro-dashboard.branding.app_name', config('app.name', 'Laravel'))); ?></title>

    <!-- High-End Elite Typography -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <style>
        /* Global Elite UI Master Kit */
        :root {
            --elite-slate-900: #0f172a;
            --elite-indigo-600: #4f46e5;
            --elite-emerald-600: #059669;
            --elite-rose-600: #e11d48;
            --elite-slate-400: #94a3b8;
            --elite-bg-soft: #f8fafc;
            --elite-border: #f1f5f9;
        }

        body { font-family: 'Inter', sans-serif; background-color: var(--elite-bg-soft) !important; color: var(--elite-slate-900); }
        h1, h2, h3, h4, h5, h6, .page-title, .lead-title { font-family: 'Outfit', sans-serif !important; letter-spacing: -0.02em; }

        /* Master Utility Overrides */
        .main-content { background: var(--elite-bg-soft); }
        .page-content { padding: 40px !important; }

        .elite-card-master {
            background: #ffffff; border-radius: 20px; border: 1px solid var(--elite-border);
            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.05); transition: 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .elite-card-master:hover { transform: translateY(-4px); box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.05); border-color: #e2e8f0; }

        /* Unified Status Badges */
        .elite-badge {
            display: inline-flex; align-items: center; padding: 4px 10px; border-radius: 6px;
            font-size: 10px; font-weight: 900; text-transform: uppercase; letter-spacing: 0.5px;
        }
        .badg-success { background: #ecfdf5; color: var(--elite-emerald-600); border: 1px solid #d1fae5; }
        .badg-primary { background: #eef2ff; color: var(--elite-indigo-600); border: 1px solid #e0e7ff; }
        .badg-danger { background: #fff1f2; color: var(--elite-rose-600); border: 1px solid #ffe4e6; }
        .badg-warning { background: #fff7ed; color: #d97706; border: 1px solid #ffedd5; }

        /* Elite Sidebar Enhancements */
        .dashboard-layout .sidebar { border-right: 1px solid var(--elite-border) !important; background: #ffffff !important; box-shadow: none !important; }
        .sidebar .nav-link { font-weight: 700; color: #64748b; font-size: 13px; border-radius: 10px; margin: 4px 12px; }
        .sidebar .nav-link.active { background: var(--elite-slate-900) !important; color: #ffffff !important; }
        .sidebar .nav-link:hover:not(.active) { background: rgba(0,0,0,0.02); }

        /* Page Transitions */
        .page-content { animation: elitePageFade 0.6s cubic-bezier(0.16, 1, 0.3, 1); }
        @keyframes elitePageFade { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
    </style>

    <?php echo $__env->make('tyro-dashboard::partials.styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>
    <?php echo $__env->make('tyro-dashboard::partials.admin-bar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="dashboard-layout">
        <!-- Sidebar - Conditional based on role -->
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'admin', 'superadmin')): ?>
            <?php echo $__env->make('tyro-dashboard::partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php else: ?>
            <?php echo $__env->make('tyro-dashboard::partials.user-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <!-- Main Content -->
        <div class="main-content">
            <div class="sticky-topbar-wrapper">
                <!-- Top Bar -->
                <?php echo $__env->make('tyro-dashboard::partials.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <!-- Impersonation Banner -->
                <?php echo $__env->make('tyro-dashboard::partials.impersonation-banner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>

            <!-- Page Content -->
            <main class="page-content">
                <!-- Flash Messages -->
                <?php echo $__env->make('tyro-dashboard::partials.flash-messages', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>

    <!-- Mobile Sidebar Overlay -->
    <div class="sidebar-overlay" onclick="toggleSidebar()"></div>

    <!-- Global Modal -->
    <?php echo $__env->make('tyro-dashboard::partials.modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('tyro-dashboard::partials.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH C:\Users\Mahadi Hassan Arif\Desktop\Sales CRM\resources\views/vendor/tyro-dashboard/layouts/app.blade.php ENDPATH**/ ?>