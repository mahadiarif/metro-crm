<?php $__env->startSection('title', 'Audit Logs'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<a href="<?php echo e(route('tyro-dashboard.index')); ?>">Dashboard</a>
<span class="breadcrumb-separator">/</span>
<span>Audit Logs</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div class="page-header-row">
        <div>
            <h1 class="page-title">Audit Logs</h1>
            <p class="page-description">Track system activity, security events, and administrative changes.</p>
        </div>
        <div style="display: flex; gap: 0.5rem;">
            <a href="<?php echo e(route('tyro-dashboard.audits.export', request()->query())); ?>" class="btn btn-secondary">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
                Export CSV
            </a>
            <form action="<?php echo e(route('tyro-dashboard.audits.flush', request()->query())); ?>" method="POST" id="flush-audits-form">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="button" class="btn btn-danger" onclick="event.preventDefault(); showDanger('Flush Audit Logs', 'Are you sure you want to permanently delete all audit log entries?').then(confirmed => { if (confirmed) document.getElementById('flush-audits-form').submit(); });">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M3 6h18M8 6V4a1 1 0 011-1h6a1 1 0 011 1v2m1 0v14a2 2 0 01-2 2H9a2 2 0 01-2-2V6h10z" />
                    </svg>
                    Flush All Logs
                </button>
            </form>
        </div>
    </div>
</div>

<div class="card" style="margin-bottom: 1rem;">
    <div class="card-body">
        <form action="<?php echo e(route('tyro-dashboard.audits.index')); ?>" method="GET">
            <div class="filters-bar" style="flex-wrap: wrap; gap: 0.75rem;">
                <div class="search-box" style="min-width: 260px; flex: 1;">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                    <input type="text" name="search" class="form-input" placeholder="Search event, actor, target..." value="<?php echo e($filters['search'] ?? ''); ?>">
                </div>

                <div class="filter-group">
                    <label class="filter-label">Event:</label>
                    <select name="event" class="form-select" style="min-width: 180px;">
                        <option value="">All Events</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $eventOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($eventName); ?>" <?php echo e(($filters['event'] ?? '') === $eventName ? 'selected' : ''); ?>><?php echo e($eventName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </select>
                </div>

                <div class="filter-group">
                    <label class="filter-label">Actor:</label>
                    <input type="text" name="actor" class="form-input" style="min-width: 180px;" placeholder="system, id, name, email" value="<?php echo e($filters['actor'] ?? ''); ?>">
                </div>

                <div class="filter-group">
                    <label class="filter-label">From:</label>
                    <input type="datetime-local" name="from" class="form-input" value="<?php echo e($filters['from'] ?? ''); ?>">
                </div>

                <div class="filter-group">
                    <label class="filter-label">To:</label>
                    <input type="datetime-local" name="to" class="form-input" value="<?php echo e($filters['to'] ?? ''); ?>">
                </div>

                <div class="filter-group">
                <button type="submit" class="btn btn-secondary">Filter</button>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($filters['search']) || !empty($filters['event']) || !empty($filters['actor']) || !empty($filters['from']) || !empty($filters['to'])): ?>
                    <a href="<?php echo e(route('tyro-dashboard.audits.index')); ?>" class="btn btn-ghost">Clear</a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($logs->count()): ?>
        <form action="<?php echo e(route('tyro-dashboard.audits.bulk-destroy', request()->query())); ?>" method="POST" id="bulk-delete-form">
            <?php echo csrf_field(); ?>
            <div class="card-body" style="border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 0.75rem; justify-content: space-between;">
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <label style="display: inline-flex; align-items: center; gap: 0.5rem; font-size: 0.875rem; color: var(--muted-foreground);">
                        <input type="checkbox" id="select-all-logs">
                        Select All on page
                    </label>
                </div>
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <label class="filter-label" style="margin: 0; white-space: nowrap;">Per Page:</label>
                    <select id="per-page-select" name="per_page" class="form-select" style="min-width: 100px;" onchange="updatePerPage(this.value)">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = [20, 50, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($size); ?>" <?php echo e((int)($filters['per_page'] ?? 20) === $size ? 'selected' : ''); ?>><?php echo e($size); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </select>
                    <button type="button" class="btn btn-danger" id="bulk-delete-btn" disabled onclick="event.preventDefault(); submitBulkDelete();">Delete Selected</button>
                </div>
            </div>

            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th style="width: 42px;"></th>
                            <th>Time</th>
                            <th>Event</th>
                            <th>Actor</th>
                            <th>Target</th>
                            <th>Summary</th>
                            <th style="text-align: right;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="row-checkbox" name="selected_ids[]" value="<?php echo e($log->id); ?>">
                                </td>
                                <td>
                                    <span style="font-size: 0.875rem; color: var(--foreground);"><?php echo e(optional($log->created_at)->format('Y-m-d H:i:s')); ?></span>
                                </td>
                                <td>
                                    <code style="padding: 0.25rem 0.5rem; background-color: var(--muted); border-radius: 0.25rem; font-size: 0.8125rem;"><?php echo e($log->event); ?></code>
                                </td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($log->user): ?>
                                        <div style="font-size: 0.875rem;">
                                            <a href="<?php echo e(route('tyro-dashboard.users.edit', $log->user->id)); ?>" style="font-weight: 500; color: var(--primary); text-decoration: none;">
                                                <?php echo e($log->user->name); ?>

                                            </a>
                                        </div>
                                    <?php else: ?>
                                        <span class="badge badge-secondary">System</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td>
                                    <?php
                                        $targetType = class_basename($log->auditable_type ?? 'System');
                                        $targetId = $log->auditable_id;
                                        $targetRoute = null;

                                        if ($targetId) {
                                            if ($targetType === 'User') {
                                                $targetRoute = route('tyro-dashboard.users.edit', $targetId);
                                            } elseif ($targetType === 'Role') {
                                                $targetRoute = route('tyro-dashboard.roles.show', $targetId);
                                            } elseif ($targetType === 'Privilege') {
                                                $targetRoute = route('tyro-dashboard.privileges.show', $targetId);
                                            }
                                        }
                                    ?>

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($targetRoute): ?>
                                        <a href="<?php echo e($targetRoute); ?>" style="font-size: 0.875rem; color: var(--primary); text-decoration: none;">
                                            <?php echo e($targetType); ?> #<?php echo e($targetId); ?>

                                        </a>
                                    <?php else: ?>
                                        <span style="font-size: 0.875rem; color: var(--muted-foreground);">
                                            <?php echo e($targetType); ?>

                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($targetId): ?>
                                                #<?php echo e($targetId); ?>

                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td>
                                    <span style="font-size: 0.875rem; color: var(--foreground);"><?php echo e(\Illuminate\Support\Str::limit($log->summary, 100)); ?></span>
                                </td>
                                <td>
                                    <div class="action-buttons" style="justify-content: flex-end;">
                                        <form action="<?php echo e(route('tyro-dashboard.audits.destroy', array_merge(request()->query(), ['id' => $log->id]))); ?>" method="POST" id="delete-log-form-<?php echo e($log->id); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="button" class="action-btn action-btn-danger" title="Delete" onclick="event.preventDefault(); showDanger('Delete Audit Log', 'Delete this audit log entry permanently?').then(confirmed => { if(confirmed) document.getElementById('delete-log-form-<?php echo e($log->id); ?>').submit(); })">
                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                                </svg>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </form>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($logs->hasPages()): ?>
            <div class="pagination">
                <?php echo e($logs->links()); ?>

            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php else: ?>
        <div class="empty-state">
            <svg class="empty-state-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            <h3 class="empty-state-title">No audit logs found</h3>
            <p class="empty-state-description">No entries match your current filters.</p>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    function updatePerPage(value) {
        const url = new URL(window.location.href);
        url.searchParams.set('per_page', value);
        url.searchParams.delete('page');
        window.location.href = url.toString();
    }

    function updateBulkDeleteButtonState() {
        const checkedCount = document.querySelectorAll('.row-checkbox:checked').length;
        const bulkDeleteBtn = document.getElementById('bulk-delete-btn');
        if (bulkDeleteBtn) {
            bulkDeleteBtn.disabled = checkedCount === 0;
        }
    }

    function submitBulkDelete() {
        const checkedCount = document.querySelectorAll('.row-checkbox:checked').length;
        if (checkedCount === 0) {
            return;
        }

        showDanger('Delete Selected Audit Logs', `Delete ${checkedCount} selected audit log entr${checkedCount > 1 ? 'ies' : 'y'} permanently?`)
            .then(confirmed => {
                if (confirmed) {
                    document.getElementById('bulk-delete-form').submit();
                }
            });
    }

    document.addEventListener('DOMContentLoaded', function () {
        const selectAll = document.getElementById('select-all-logs');
        const rowCheckboxes = document.querySelectorAll('.row-checkbox');

        if (selectAll) {
            selectAll.addEventListener('change', function () {
                rowCheckboxes.forEach((checkbox) => {
                    checkbox.checked = selectAll.checked;
                });
                updateBulkDeleteButtonState();
            });
        }

        rowCheckboxes.forEach((checkbox) => {
            checkbox.addEventListener('change', function () {
                const allChecked = rowCheckboxes.length > 0 && Array.from(rowCheckboxes).every((input) => input.checked);
                if (selectAll) {
                    selectAll.checked = allChecked;
                }
                updateBulkDeleteButtonState();
            });
        });

        updateBulkDeleteButtonState();
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tyro-dashboard::layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Mahadi Hassan Arif\Desktop\Sales CRM\resources\views/vendor/tyro-dashboard/audits/index.blade.php ENDPATH**/ ?>