<?php $__env->startSection('title', 'Invitation Links'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<a href="<?php echo e(route('tyro-dashboard.index')); ?>">Dashboard</a>
<span class="breadcrumb-separator">/</span>
<span>Invitation Links</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div class="page-header-row">
        <div>
            <h1 class="page-title">Invitation Links</h1>
            <p class="page-description">Manage user invitation and referral links.</p>
        </div>
        <a href="<?php echo e(route('tyro-dashboard.invitations.admin.create')); ?>" class="btn btn-primary">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
            </svg>
            Create Invitation Link
        </a>
    </div>
</div>

<!-- Search -->
<div class="card" style="margin-bottom: 1rem;">
    <div class="card-body">
        <form action="<?php echo e(route('tyro-dashboard.invitations.admin.index')); ?>" method="GET">
            <div class="filters-bar">
                <div class="search-box">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                    <input type="text" name="search" class="form-input" placeholder="Search by user name, email, or hash..." value="<?php echo e(request('search')); ?>">
                </div>
                <button type="submit" class="btn btn-secondary">Search</button>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(request('search')): ?>
                    <a href="<?php echo e(route('tyro-dashboard.invitations.admin.index')); ?>" class="btn btn-ghost">Clear</a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </form>
    </div>
</div>

<!-- Invitation Links Table -->
<div class="card">
    <div class="card-body" style="padding: 0;">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($links->count()): ?>
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th style="width: 25%;">User</th>
                        <th style="width: 20%;">Email</th>
                        <th style="width: 15%; text-align: center;">Referrals</th>
                        <th style="width: 20%;">Created</th>
                        <th style="width: 20%; text-align: right;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div class="user-cell">
                                <div class="user-cell-avatar" style="<?php echo e(($link->user->profile_photo_path || $link->user->use_gravatar) ? 'background: none; padding: 0;' : ''); ?>">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($link->user->profile_photo_path || ($link->user->use_gravatar && $link->user->email)): ?>
                                        <img src="<?php echo e($link->user->profile_photo_url); ?>" alt="<?php echo e($link->user->name); ?>" style="width: 100%; height: 100%; object-fit: cover; border-radius: 50%;">
                                    <?php else: ?>
                                        <?php echo e(strtoupper(substr($link->user->name ?? 'U', 0, 1))); ?>

                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                                <div class="user-cell-info">
                                    <div class="user-cell-name"><?php echo e($link->user->name ?? 'Unknown'); ?></div>
                                </div>
                            </div>
                        </td>
                        <td><?php echo e($link->user->email ?? 'N/A'); ?></td>
                        <td style="text-align: center;">
                            <span class="badge badge-primary"><?php echo e($link->referrals->count()); ?></span>
                        </td>
                        <td>
                            <span style="font-size: 0.875rem;"><?php echo e($link->created_at->format('M d, Y')); ?></span>
                            <br>
                            <span style="font-size: 0.75rem; color: var(--muted-foreground);"><?php echo e($link->created_at->format('h:i A')); ?></span>
                        </td>
                        <td style="text-align: right;">
                            <div class="btn-group">
                                <button onclick="copyToClipboard('<?php echo e(url('/register?invite=' . $link->hash)); ?>')" class="btn btn-sm btn-secondary" title="Copy invitation URL">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                                    </svg>
                                </button>
                                <form action="<?php echo e(route('tyro-dashboard.invitations.admin.destroy', $link->id)); ?>" method="POST" style="display: inline;" id="delete-invitation-form-<?php echo e($link->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="button" class="btn btn-sm btn-danger" title="Delete invitation link" onclick="event.preventDefault(); showDanger('Delete Invitation Link', 'Are you sure you want to delete this invitation link?<?php echo e($link->referrals->count() > 0 ? ' This will also remove ' . $link->referrals->count() . ' referral record(s).' : ''); ?>').then(confirmed => { if(confirmed) document.getElementById('delete-invitation-form-<?php echo e($link->id); ?>').submit(); })">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                        </svg>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($links->hasPages()): ?>
        <div class="pagination-container">
            <?php echo e($links->links()); ?>

        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php else: ?>
        <div class="empty-state">
            <div class="empty-state-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
                </svg>
            </div>
            <h3 class="empty-state-title">No invitation links found</h3>
            <p class="empty-state-description">Create an invitation link to get started with referrals.</p>
            <a href="<?php echo e(route('tyro-dashboard.invitations.admin.create')); ?>" class="btn btn-primary">Create Invitation Link</a>
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div>

<script>
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showSuccess('Invitation link copied to clipboard!');
    }).catch(err => {
        console.error('Failed to copy:', err);
    });
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tyro-dashboard::layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Mahadi Hassan Arif\Desktop\Sales CRM\resources\views/vendor/tyro-dashboard/invitations/admin-index.blade.php ENDPATH**/ ?>