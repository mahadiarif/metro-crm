

<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<span>Dashboard</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div class="page-header-row">
        <div>
            <h1 class="page-title">Sales CRM Overview</h1>
            <p class="page-description" style="font-size: 1rem;">Daily performance and pipeline tracking.</p>
        </div>
    </div>
</div>

<!-- Quick Actions Bar -->
<div class="quick-actions-bar" style="display: flex; align-items: center; justify-content: space-between; background: white; border: 1px solid #e2e8f0; border-radius: 12px; padding: 1.25rem; margin-bottom: 2rem; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
    <div>
        <h2 style="font-size: 1.125rem; font-weight: 700; color: #1e293b; margin: 0;">Activity Command Center</h2>
        <p style="font-size: 0.875rem; color: #64748b; margin: 0.25rem 0 0 0;">Priority tasks and quick entries for today.</p>
    </div>
    <div style="display: flex; gap: 0.75rem;">
        <button onclick="window.location.href='<?php echo e(route('tyro-dashboard.pipelines.kanban')); ?>'" style="background: #eef2ff; color: #4f46e5; border: none; padding: 0.625rem 1rem; border-radius: 8px; font-weight: 600; font-size: 0.875rem; cursor: pointer; transition: background 0.2s;">
            Open Kanban
        </button>
        <button style="background: #4f46e5; color: white; border: none; padding: 0.625rem 1rem; border-radius: 8px; font-weight: 600; font-size: 0.875rem; cursor: pointer; transition: opacity 0.2s;" onmouseover="this.style.opacity='0.9'" onmouseout="this.style.opacity='1'">
            + New Lead
        </button>
    </div>
</div>

<!-- Row 1: KPIs -->
<div class="stats-grid" style="margin-bottom: 2rem;">
    <div class="stat-card">
        <div class="stat-icon stat-icon-primary">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
        </div>
        <div class="stat-content">
            <div class="stat-label">Total Leads</div>
            <div class="stat-value"><?php echo e(number_format($crmStats['total_leads'] ?? 0)); ?></div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon stat-icon-info">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
        </div>
        <div class="stat-content">
            <div class="stat-label">Today's Visits</div>
            <div class="stat-value"><?php echo e(number_format($crmStats['today_visits'] ?? 0)); ?></div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon stat-icon-warning">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
        </div>
        <div class="stat-content">
            <div class="stat-label">Today's Followups</div>
            <div class="stat-value"><?php echo e(number_format($crmStats['today_followups'] ?? 0)); ?></div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon stat-icon-success">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-10V6m0 12v-2m6-6a6 6 0 11-12 0 6 6 0 0112 0z" />
            </svg>
        </div>
        <div class="stat-content">
            <div class="stat-label">Monthly Sales</div>
            <div class="stat-value">৳ <?php echo e(number_format($crmStats['monthly_sales'] ?? 0, 2)); ?></div>
        </div>
    </div>
</div>

<!-- Row 2: Charts -->
<div class="grid-2" style="margin-bottom: 2rem;">
    
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Monthly Revenue Chart</h3>
            <span class="badge badge-secondary">BDT (৳)</span>
        </div>
        <div class="card-body">
            <div style="font-size: 1.5rem; font-weight: 700; margin-bottom: 1rem;">৳ <?php echo e(number_format($crmCharts['revenue_total_bdt'] ?? 0, 2)); ?></div>
            <div style="border: 1px solid var(--border); border-radius: 10px; padding: 1rem; background: var(--muted);">
                <svg viewBox="0 0 600 180" width="100%" height="150" preserveAspectRatio="none" style="display:block; color: var(--primary);">
                    <g opacity="0.35" stroke="currentColor" style="color: var(--muted-foreground);">
                        <path d="M0 150 H600" />
                        <path d="M0 90 H600" />
                        <path d="M0 30 H600" />
                    </g>
                    <path d="<?php echo e($crmCharts['revenue_area_path']); ?>" fill="currentColor" opacity="0.12"></path>
                    <path d="<?php echo e($crmCharts['revenue_line_path']); ?>" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
                <div style="display:flex; justify-content: space-between; margin-top: 0.5rem; font-size: 0.8125rem; color: var(--muted-foreground);">
                    <span><?php echo e($crmCharts['revenue_range_left']); ?></span>
                    <span><?php echo e($crmCharts['revenue_range_right']); ?></span>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Lead Status Distribution</h3>
        </div>
        <div class="card-body">
            <div style="display: grid; grid-template-columns: 140px 1fr; gap: 1.5rem; align-items: center; min-height: 200px;">
                <div style="display:flex; align-items:center; justify-content:center;">
                    <svg viewBox="0 0 42 42" width="140" height="140" style="display:block; transform: rotate(-90deg);">
                        <circle cx="21" cy="21" r="15.915" fill="transparent" stroke="var(--border)" stroke-width="5"></circle>
                        <?php ($offset = 100); ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $crmCharts['status_donut']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($slice['pct'] > 0): ?>
                            <circle
                                cx="21" cy="21" r="15.915"
                                fill="transparent"
                                stroke="<?php echo e($slice['color']); ?>"
                                stroke-width="5"
                                stroke-dasharray="<?php echo e($slice['pct']); ?> <?php echo e(100 - $slice['pct']); ?>"
                                stroke-dashoffset="<?php echo e($offset); ?>"
                                stroke-linecap="round"
                            ></circle>
                            <?php ($offset -= $slice['pct']); ?>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </svg>
                </div>
                <div style="display:flex; flex-direction:column; gap: 0.75rem;">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $crmCharts['status_donut']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div style="display:flex; align-items:center; justify-content: space-between; gap: 1rem;">
                            <div style="display:flex; align-items:center; gap: 0.5rem;">
                                <span style="width: 10px; height: 10px; border-radius: 9999px; background: <?php echo e($slice['color']); ?>;"></span>
                                <span style="font-size: 0.9375rem; color: var(--foreground);"><?php echo e($slice['label']); ?></span>
                            </div>
                            <div style="font-size: 0.9375rem; color: var(--muted-foreground); font-weight: 600;"><?php echo e($slice['count']); ?></div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Row 3: Product & Executive Analytics -->
<div class="grid-2" style="margin-bottom: 2rem;">
    
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Product Wise Sales</h3>
            <span class="badge badge-secondary">Top 5 This Month</span>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Package</th>
                            <th style="text-align: right;">Total Sales</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $crmCharts['product_sales']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td style="font-weight: 600;"><?php echo e($item->product); ?></td>
                            <td><span class="badge badge-secondary" style="font-size: 0.75rem;"><?php echo e($item->package); ?></span></td>
                            <td style="text-align: right; font-weight: 700; color: var(--primary);">৳ <?php echo e(number_format($item->total_sales, 2)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="3" style="text-align: center; color: var(--muted-foreground); padding: 2rem;">No sales records found.</td>
                        </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Executive Performance</h3>
            <span class="badge badge-secondary">Top Performers</span>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Executive</th>
                            <th style="text-align: center;">Deals</th>
                            <th style="text-align: right;">Revenue</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $crmCharts['executive_performance']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('tyro-dashboard.reports.user-performance', $perf->user->id)); ?>" style="font-weight: 600; color: var(--primary); text-decoration: none;">
                                    <?php echo e($perf->user->name ?? 'Unknown'); ?>

                                </a>
                            </td>
                            <td style="text-align: center;"><?php echo e($perf->total_deals); ?></td>
                            <td style="text-align: right; font-weight: 600; color: #10b981;">৳ <?php echo e(number_format($perf->total_amount, 2)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="3" style="text-align: center; color: var(--muted-foreground);">No performance data available.</td>
                        </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Row 4: Lists -->
<div class="grid-2">
    
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Today's Visits</h3>
            <span class="badge badge-info"><?php echo e($crmCharts['today_visits_list']->count()); ?> Interaction(s)</span>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Lead / Client</th>
                            <th>Executive</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $crmCharts['today_visits_list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <div style="font-weight: 600;"><?php echo e($visit->lead->client_name ?? 'N/A'); ?></div>
                                <div style="font-size: 0.75rem; color: var(--muted-foreground);"><?php echo e($visit->lead->company_name ?? ''); ?></div>
                            </td>
                            <td><?php echo e($visit->user->name ?? 'Unknown'); ?></td>
                            <td><?php echo e($visit->visit_date->format('h:i A')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="3" style="text-align: center; padding: 2rem; color: var(--muted-foreground);">No visits logged today yet.</td>
                        </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Upcoming Followups</h3>
            <span class="badge badge-warning">Pending tasks</span>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Lead / Client</th>
                            <th>Due Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $crmCharts['upcoming_followups_list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $followup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <div style="font-weight: 600;"><?php echo e($followup->lead->client_name ?? 'N/A'); ?></div>
                                <div style="font-size: 0.75rem; color: var(--muted-foreground);"><?php echo e($followup->lead->company_name ?? ''); ?></div>
                            </td>
                            <td>
                                <div><?php echo e($followup->scheduled_at->format('M d, Y')); ?></div>
                                <div style="font-size: 0.75rem; color: var(--muted-foreground);"><?php echo e($followup->scheduled_at->format('h:i A')); ?></div>
                            </td>
                            <td>
                                <span class="badge <?php echo e($followup->scheduled_at->isPast() ? 'badge-danger' : 'badge-secondary'); ?>">
                                    <?php echo e($followup->scheduled_at->isPast() ? 'Overdue' : 'Scheduled'); ?>

                                </span>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="3" style="text-align: center; padding: 2rem; color: var(--muted-foreground);">No upcoming followups scheduled.</td>
                        </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Row 5: Latest Leads & Sales -->
<div class="grid-2" style="margin-top: 2rem;">
    
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Latest Leads</h3>
            <span class="badge badge-primary">Newest 5</span>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Lead Name</th>
                            <th>Company</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $crmCharts['latest_leads']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td style="font-weight: 600;"><?php echo e($lead->client_name); ?></td>
                            <td><?php echo e($lead->company_name); ?></td>
                            <td>
                                <span class="badge badge-secondary"><?php echo e(ucfirst($lead->status)); ?></span>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="3" style="text-align: center; padding: 2rem; color: var(--muted-foreground);">No leads found.</td>
                        </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
    <div class="card" style="height: 100%;">
        <div class="card-header">
            <h3 class="card-title">Latest Sales</h3>
            <span class="badge badge-success">Newest 5</span>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Client</th>
                            <th>Amount</th>
                            <th style="text-align: right;">Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $crmCharts['latest_sales']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <div style="font-weight: 600;"><?php echo e($sale->lead->client_name ?? 'N/A'); ?></div>
                                <div style="font-size: 0.75rem; color: var(--muted-foreground);">
                                    <?php echo e($sale->service->name ?? ''); ?>

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sale->servicePackage): ?>
                                        (<?php echo e($sale->servicePackage->name); ?>)
                                    <?php elseif($sale->lead->servicePackage): ?>
                                        (<?php echo e($sale->lead->servicePackage->name); ?>)
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </td>
                            <td style="color: #10b981; font-weight: 600;">৳ <?php echo e(number_format($sale->amount, 2)); ?></td>
                            <td style="text-align: right; color: var(--muted-foreground);"><?php echo e($sale->closed_at->format('M d, Y')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="3" style="text-align: center; padding: 2rem; color: var(--muted-foreground);">No sales found.</td>
                        </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Row 6: Recent Activity -->
<div style="width: 100%; margin-top: 2rem;">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Recent Activity</h3>
            <span class="badge badge-secondary">Full Width View</span>
        </div>
        <div class="card-body" style="padding: 0;">
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Event</th>
                            <th>Actor</th>
                            <th>Status</th>
                            <th style="text-align:right;">When</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $crmCharts['recent_activities']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <div style="font-weight: 600;"><?php echo e($row['title']); ?></div>
                                    <div style="font-size: 0.8125rem; color: var(--muted-foreground);"><?php echo e($row['subtitle']); ?></div>
                                </td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 0.625rem;">
                                        <div style="width: 32px; height: 32px; border-radius: 9999px; background: var(--primary); color: white; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 0.875rem;">
                                            <?php echo e(strtoupper(substr($row['actor'], 0, 1))); ?>

                                        </div>
                                        <div>
                                            <div style="font-size: 0.9375rem; font-weight: 500;"><?php echo e($row['actor']); ?></div>
                                            <div style="font-size: 0.8125rem; color: var(--muted-foreground);"><?php echo e($row['actor_meta']); ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge <?php echo e($row['status_badge_class']); ?>"><?php echo e($row['status']); ?></span>
                                </td>
                                <td style="text-align:right; color: var(--muted-foreground);"><?php echo e($row['when']); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" style="text-align: center; padding: 2rem; color: var(--muted-foreground);">No recent activities.</td>
                            </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tyro-dashboard::layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Mahadi Hassan Arif\Desktop\Sales CRM\resources\views/vendor/tyro-dashboard/dashboard/admin.blade.php ENDPATH**/ ?>