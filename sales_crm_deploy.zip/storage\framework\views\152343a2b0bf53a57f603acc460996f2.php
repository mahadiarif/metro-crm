<div class="visit-modal-container">
    <div class="fixed inset-0 z-50 overflow-y-auto <?php echo e($isModalOpen ? 'd-block' : 'd-none'); ?>" 
         style="background: rgba(0, 0, 0, 0.5); backdrop-filter: blur(4px); transition: all 0.3s ease; position: fixed; top: 0; left: 0; width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; padding: 1rem;">
        
        <div class="card w-100 shadow-xl border-0 overflow-hidden" style="max-width: 900px; background: white; border-radius: 12px;">
            
            <div class="card-header py-4 px-5" style="background: #fdfdfd; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h5 class="card-title mb-0" style="font-weight: 800; font-size: 1.25rem; color: #111; letter-spacing: -0.02em;">Log Call Engagement</h5>
                    <p class="text-xs text-muted-foreground mb-0 font-medium">Record outcome for <?php echo e($leadName); ?></p>
                </div>
                <button wire:click="close" style="background: #f3f4f6; border: none; width: 32px; height: 32px; border-radius: 50%; cursor: pointer; color: #666; display: flex; align-items: center; justify-content: center; transition: all 0.2s;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                </button>
            </div>

            <div class="card-body p-5" style="max-height: 80vh; overflow-y: auto;">
                <!-- Section 1: Client Profile -->
                <div class="mb-5">
                    <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1.5rem;">
                        <div style="width: 24px; height: 3px; background: #3b82f6; border-radius: 2px;"></div>
                        <h6 style="font-size: 0.75rem; font-weight: 800; color: #3b82f6; text-transform: uppercase; letter-spacing: 0.1em; margin: 0;">Client Profile Sync</h6>
                    </div>

                    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 1rem;">
                        <div class="form-group">
                            <label style="display: block; font-size: 0.65rem; font-weight: 700; color: #666; text-transform: uppercase; margin-bottom: 0.4rem;">Company Name</label>
                            <input type="text" value="<?php echo e($leadName); ?>" class="form-input" style="width: 100%; border: 1px solid #e5e7eb; border-radius: 6px; padding: 0.5rem; background: #f9fafb;" readonly>
                        </div>
                        <div class="form-group">
                            <label style="display: block; font-size: 0.65rem; font-weight: 700; color: #666; text-transform: uppercase; margin-bottom: 0.4rem;">Contact Person</label>
                            <input type="text" wire:model="contactPerson" class="form-input" style="width: 100%; border: 1px solid #e5e7eb; border-radius: 6px; padding: 0.5rem;">
                        </div>
                        <div class="form-group">
                            <label style="display: block; font-size: 0.65rem; font-weight: 700; color: #666; text-transform: uppercase; margin-bottom: 0.4rem;">Designation</label>
                            <input type="text" wire:model="designation" class="form-input" style="width: 100%; border: 1px solid #e5e7eb; border-radius: 6px; padding: 0.5rem;">
                        </div>
                        <div class="form-group">
                            <label style="display: block; font-size: 0.65rem; font-weight: 700; color: #666; text-transform: uppercase; margin-bottom: 0.4rem;">Phone / Cell No</label>
                            <input type="text" wire:model="phone" class="form-input" style="width: 100%; border: 1px solid #e5e7eb; border-radius: 6px; padding: 0.5rem;">
                        </div>
                        <div class="form-group">
                            <label style="display: block; font-size: 0.65rem; font-weight: 700; color: #666; text-transform: uppercase; margin-bottom: 0.4rem;">Email Address</label>
                            <input type="email" wire:model="email" class="form-input" style="width: 100%; border: 1px solid #e5e7eb; border-radius: 6px; padding: 0.5rem;">
                        </div>
                        <div class="form-group">
                            <label style="display: block; font-size: 0.65rem; font-weight: 700; color: #666; text-transform: uppercase; margin-bottom: 0.4rem;">Lead Source</label>
                            <select wire:model="leadSource" class="form-select" style="width: 100%; border: 1px solid #e5e7eb; border-radius: 6px; padding: 0.5rem;">
                                <option value="">Select...</option>
                                <option value="Self Generated">Self Generated</option>
                                <option value="Reference">Reference</option>
                                <option value="Social Media">Social Media</option>
                                <option value="Website">Website</option>
                            </select>
                        </div>
                        <div class="form-group" style="grid-column: span 2;">
                            <label style="display: block; font-size: 0.65rem; font-weight: 700; color: #666; text-transform: uppercase; margin-bottom: 0.4rem;">Site Location / Address</label>
                            <input type="text" wire:model="address" class="form-input" style="width: 100%; border: 1px solid #e5e7eb; border-radius: 6px; padding: 0.5rem;">
                        </div>
                    </div>
                </div>

                <!-- Section 2: Market Context -->
                <div class="mb-5 p-4 rounded bg-muted/5 border border-dashed border-muted-foreground/20">
                    <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1rem;">
                        <div style="width: 24px; height: 3px; background: #f59e0b; border-radius: 2px;"></div>
                        <h6 style="font-size: 0.75rem; font-weight: 800; color: #f59e0b; text-transform: uppercase; letter-spacing: 0.1em; margin: 0;">Market Intelligence</h6>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                        <div class="form-group">
                            <label style="display: block; font-size: 0.65rem; font-weight: 700; color: #666; text-transform: uppercase; margin-bottom: 0.4rem;">Competitor or Existing Provider</label>
                            <input type="text" wire:model="existingProvider" class="form-input" style="width: 100%; border: 1px solid #e5e7eb; border-radius: 6px; padding: 0.5rem;" placeholder="e.g. AmberIT, Carnival">
                        </div>
                        <div class="form-group">
                            <label style="display: block; font-size: 0.65rem; font-weight: 700; color: #666; text-transform: uppercase; margin-bottom: 0.4rem;">Current Service Usage</label>
                            <input type="text" wire:model="currentUsage" class="form-input" style="width: 100%; border: 1px solid #e5e7eb; border-radius: 6px; padding: 0.5rem;" placeholder="e.g. 50Mbps Bandwidth">
                        </div>
                    </div>
                </div>

                <!-- Section 3: Call Engagement -->
                <div style="display: grid; grid-template-columns: 200px 1fr; gap: 2rem;">
                    <div style="background: #f8f9fa; border: 1px solid #eee; border-radius: 10px; padding: 1.25rem;">
                        <h6 style="font-size: 0.65rem; font-weight: 800; color: #666; text-transform: uppercase; margin-bottom: 1.5rem;">Outreach Stage</h6>
                        <div style="display: flex; flex-direction: column; gap: 1.25rem;">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php for($i = 1; $i <= 3; $i++): ?>
                            <div style="display: flex; align-items: center; gap: 0.75rem;">
                                <div style="width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 0.75rem; 
                                    <?php echo e($i < $callCount ? 'background: #10b981; color: white;' : ($i === $callCount ? 'background: #3b82f6; color: white;' : 'background: #e5e7eb; color: #999;')); ?>">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($i < $callCount): ?> ✓ <?php else: ?> <?php echo e($i); ?> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                                <div style="font-size: 0.7rem; font-weight: 700; <?php echo e($i === $callCount ? 'color: #3b82f6;' : 'color: #666;'); ?>">
                                    Call #<?php echo e($i); ?>

                                </div>
                            </div>
                            <?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>

                    <div>
                        <h6 style="font-size: 0.65rem; font-weight: 800; color: #666; text-transform: uppercase; margin-bottom: 1rem;">Interaction Outcome</h6>
                        <div style="display: flex; gap: 0.5rem; margin-bottom: 1.5rem;">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ['follow_up' => 'Retry', 'service_request' => 'Win', 'not_interested' => 'Drop']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label style="flex: 1; border: 2px solid <?php echo e($outcome === $val ? '#3b82f6' : '#eee'); ?>; border-radius: 8px; padding: 1rem 0.5rem; text-align: center; cursor: pointer; transition: all 0.2s; position: relative;
                                <?php echo e($outcome === $val ? 'background: #eff6ff;' : 'background: #fff;'); ?>">
                                <input type="radio" wire:model.live="outcome" value="<?php echo e($val); ?>" style="position: absolute; opacity: 0;">
                                <div style="font-weight: 800; text-transform: uppercase; font-size: 0.75rem; color: <?php echo e($outcome === $val ? '#3b82f6' : '#666'); ?>;"><?php echo e($label); ?></div>
                            </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        <div style="display: grid; grid-template-columns: 1fr; gap: 1rem;">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($outcome === 'follow_up'): ?>
                            <div class="form-group">
                                <label style="display: block; font-size: 0.65rem; font-weight: 700; color: #666; text-transform: uppercase; margin-bottom: 0.4rem;">Next Callback Date</label>
                                <input type="datetime-local" class="form-input" style="width: 100%; border: 1px solid #e5e7eb; border-radius: 6px; padding: 0.6rem;" wire:model="nextCallAt">
                            </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($outcome === 'not_interested'): ?>
                            <div class="form-group">
                                <label style="display: block; font-size: 0.65rem; font-weight: 700; color: #666; text-transform: uppercase; margin-bottom: 0.4rem;">Dropout Reason</label>
                                <textarea class="form-textarea" style="width: 100%; border: 1px solid #e5e7eb; border-radius: 6px; padding: 0.6rem;" wire:model="closeReason" rows="2"></textarea>
                            </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            <div class="form-group">
                                <label style="display: block; font-size: 0.65rem; font-weight: 700; color: #666; text-transform: uppercase; margin-bottom: 0.4rem;">Consultation Remarks</label>
                                <textarea class="form-textarea" style="width: 100%; border: 1px solid #e5e7eb; border-radius: 6px; padding: 0.75rem; min-height: 80px;" wire:model="notes" rows="3" placeholder="What did you discuss with the client?"></textarea>
                            </div>
                        </div>
                    </div>
            </div>

            <!-- Additive Follow-up Strategic Layer (Premium Design) -->
            <div style="background: #f8fafc; border-top: 1px solid #e2e8f0; border-bottom: 1px solid #e2e8f0; padding: 2rem 1.5rem;">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 1.5rem;">
                    <h6 style="font-size: 0.7rem; font-weight: 800; color: #64748b; text-transform: uppercase; margin: 0; display: flex; align-items: center; gap: 0.6rem; letter-spacing: 0.05em;">
                        <div style="background: #3b82f6; color: white; padding: 0.3rem; border-radius: 6px; display: flex; align-items: center; justify-content: center; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                        </div>
                        Strategic Follow-up
                    </h6>
                    <span style="background: #dbeafe; color: #1e40af; font-size: 10px; font-weight: 800; padding: 0.25rem 0.75rem; border-radius: 100px; text-transform: uppercase; letter-spacing: 0.02em;">Additive Layer</span>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                    <div class="form-group">
                        <label style="display: block; font-size: 0.65rem; font-weight: 700; color: #94a3b8; text-transform: uppercase; margin-bottom: 0.6rem; letter-spacing: 0.05em;">Call Status</label>
                        <select wire:model="callStatus" style="width: 100%; border: 1px solid #e2e8f0; border-radius: 8px; padding: 0.75rem; background: #fff; font-size: 0.85rem; font-weight: 600; color: #334155; transition: all 0.2s; cursor: pointer; outline: none; box-shadow: 0 1px 2px rgba(0,0,0,0.05);">
                            <option value="">Select Status...</option>
                            <option value="pending">⏳ Pending Queue</option>
                            <option value="in_progress">🔄 Actively Engaging</option>
                            <option value="completed">✅ Interaction Finalized</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label style="display: block; font-size: 0.65rem; font-weight: 700; color: #94a3b8; text-transform: uppercase; margin-bottom: 0.6rem; letter-spacing: 0.05em;">Target Date</label>
                        <input type="date" wire:model="nextFollowupDate" style="width: 100%; border: 1px solid #e2e8f0; border-radius: 8px; padding: 0.75rem; background: #fff; font-size: 0.85rem; font-weight: 600; color: #334155; outline: none; box-shadow: 0 1px 2px rgba(0,0,0,0.05);">
                    </div>
                </div>
            </div>

            <div class="card-footer py-4 px-5" style="background: #fdfdfd; border-top: 1px solid #eee; display: flex; justify-content: flex-end; gap: 1rem;">
                <button wire:click="close" style="background: transparent; border: 1px solid #e5e7eb; border-radius: 8px; padding: 0.75rem 1.5rem; font-weight: 700; color: #666; cursor: pointer; font-size: 0.85rem;">Discard Session</button>
                <button wire:click="saveOutcome" style="background: #111; color: white; border: none; border-radius: 8px; padding: 0.75rem 2rem; font-weight: 800; cursor: pointer; font-size: 0.85rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);">
                    Confirm Call Log
                </button>
            </div>
        </div>
    </div>

    <style>
        .modal-grid-layout {
            display: grid;
            grid-template-columns: 240px 1fr;
            gap: 1.5rem;
        }
        @media (max-width: 768px) {
            .modal-grid-layout {
                grid-template-columns: 1fr;
            }
        }
    </style>
</div>
<?php /**PATH C:\Users\Mahadi Hassan Arif\Desktop\Sales CRM\resources\views/livewire/sales-call/outcome-modal.blade.php ENDPATH**/ ?>